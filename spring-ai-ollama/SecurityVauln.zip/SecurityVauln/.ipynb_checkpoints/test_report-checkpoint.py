import os
import sys
import re
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from datetime import datetime
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

# Ensure UTF-8 printing on Windows console
if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8')

# Severity config
SEVERITY_SCORE   = {'Low': 1, 'Medium': 2, 'High': 3, 'Critical': 4}
SEVERITY_COLOR   = {
    'Low'     : '#2ECC71',
    'Medium'  : '#F39C12',
    'High'    : '#E74C3C',
    'Critical': '#8E44AD'
}
SEVERITY_BG_HEX  = {
    'Low'     : 'EAFAF1',
    'Medium'  : 'FEF9E7',
    'High'    : 'FDEDEC',
    'Critical': 'F5EEF8'
}
SEVERITY_FG_HEX  = {
    'Low'     : '1E8449',
    'Medium'  : 'B7770D',
    'High'    : 'C0392B',
    'Critical': '6C3483'
}

RISK_BANDS = [
    (5,  'Safe',          '#2ECC71'),
    (15, 'Moderate Risk', '#F39C12'),
    (30, 'High Risk',     '#E74C3C'),
    (999,'Critical Risk', '#8E44AD'),
]

HF_MODEL    = 'google/flan-t5-large'
OUTPUT_XLSX = 'github_security_vulnerability_report.xlsx'
TARGET_REPO = 'mayureshnadkar-beep/spring-ai-ollama'

# Copy the draw_visualizations function from scanner
def draw_visualizations(df: pd.DataFrame, risk_report: dict):
    """Render the full 6-panel security dashboard."""
    if df.empty:
        print('ℹ️  No findings — skipping charts.')
        return

    SEV_ORDER  = ['Critical', 'High', 'Medium', 'Low']
    sc         = risk_report['sev_counts']
    tc         = risk_report['type_counts']
    sev_present= [s for s in SEV_ORDER if s in sc]
    sev_vals   = [sc[s] for s in sev_present]
    bar_colors = [SEVERITY_COLOR[s] for s in sev_present]

    fig = plt.figure(figsize=(22, 16), facecolor='#0F172A')
    fig.suptitle(
        f'🔐  Security Scan Dashboard — {risk_report["meta"]["full_name"]}',
        fontsize=17, fontweight='bold', color='white', y=0.98
    )

    AXBG = '#1E293B'

    def style_ax(ax, title):
        ax.set_facecolor(AXBG)
        ax.set_title(title, color='white', fontweight='bold', pad=10, fontsize=11)
        ax.tick_params(colors='#94A3B8')
        for sp in ax.spines.values():
            sp.set_color('#334155')

    # ── 1. Severity bar chart
    ax1 = fig.add_subplot(2, 3, 1)
    style_ax(ax1, 'Vulnerabilities by Severity')
    bars = ax1.bar(sev_present, sev_vals, color=bar_colors,
                   edgecolor='white', linewidth=0.6, width=0.55)
    ax1.set_ylabel('Count', color='#94A3B8')
    for b, v in zip(bars, sev_vals):
        ax1.text(b.get_x() + b.get_width()/2, b.get_height() + 0.05,
                 str(v), ha='center', color='white', fontweight='bold', fontsize=12)

    # ── 2. Severity pie chart
    ax2 = fig.add_subplot(2, 3, 2)
    style_ax(ax2, 'Severity Distribution')
    wedges, texts, autos = ax2.pie(
        sev_vals, labels=sev_present, colors=bar_colors,
        autopct='%1.1f%%', startangle=90,
        wedgeprops={'edgecolor': '#0F172A', 'linewidth': 2}
    )
    for t in texts + autos:
        t.set_color('white')
        t.set_fontsize(10)

    # ── 3. Vulnerability types horizontal bar
    ax3 = fig.add_subplot(2, 3, 3)
    style_ax(ax3, 'Vulnerability Categories')
    types  = list(tc.keys())[:8]
    tvals  = [tc[t] for t in types]
    tclrs  = plt.cm.Set2(np.linspace(0, 1, len(types)))
    hb     = ax3.barh([t[:28] for t in types], tvals, color=tclrs,
                       edgecolor='white', linewidth=0.4)
    ax3.set_xlabel('Count', color='#94A3B8')
    for b, v in zip(hb, tvals):
        ax3.text(b.get_width() + 0.05, b.get_y() + b.get_height()/2,
                 str(v), va='center', color='white', fontsize=9)

    # ── 4. Top vulnerable files
    ax4 = fig.add_subplot(2, 3, 4)
    style_ax(ax4, 'Top 5 Vulnerable Files')
    tf = risk_report['top_files']
    if tf:
        fnames = [os.path.basename(k)[:30] for k in tf]
        fvals  = list(tf.values())
        ax4.barh(fnames, fvals, color='#38BDF8', edgecolor='white', linewidth=0.4)
        ax4.set_xlabel('Findings', color='#94A3B8')

    # ── 5. Risk gauge
    ax5 = fig.add_subplot(2, 3, 5)
    style_ax(ax5, 'Repository Risk Status')
    ax5.set_xlim(0, 1); ax5.set_ylim(0, 1); ax5.axis('off')
    score = risk_report['total_score']
    cls   = risk_report['classification']
    cc    = risk_report['cls_color']
    circle_bg   = plt.Circle((0.5, 0.46), 0.32, color='#0F172A', fill=True)
    circle_ring = plt.Circle((0.5, 0.46), 0.32, color=cc, linewidth=8, fill=False)
    ax5.add_patch(circle_bg); ax5.add_patch(circle_ring)
    ax5.text(0.5, 0.53, str(score), ha='center', va='center',
             fontsize=38, fontweight='bold', color=cc)
    ax5.text(0.5, 0.38, 'RISK SCORE', ha='center',
             fontsize=9, color='#94A3B8')
    ax5.text(0.5, 0.11, cls, ha='center', fontsize=13,
             fontweight='bold', color=cc,
             bbox=dict(boxstyle='round,pad=0.4', facecolor='#1E293B',
                       edgecolor=cc, linewidth=2))

    # ── 6. Stacked bar — severity by type
    ax6 = fig.add_subplot(2, 3, 6)
    style_ax(ax6, 'Severity by Category (Stacked)')
    pivot = df.groupby(['Vulnerability Type', 'Severity']).size().unstack(fill_value=0)
    for s in SEV_ORDER:
        if s not in pivot.columns:
            pivot[s] = 0
    pivot = pivot[[s for s in SEV_ORDER if s in pivot.columns]]
    bottom = np.zeros(len(pivot))
    xlabels = [t[:22] for t in pivot.index]
    for sev in SEV_ORDER:
        if sev in pivot.columns:
            vals = pivot[sev].values
            ax6.bar(xlabels, vals, bottom=bottom, label=sev,
                    color=SEVERITY_COLOR[sev], edgecolor='white', linewidth=0.3)
            bottom += vals
    ax6.tick_params(axis='x', colors='#94A3B8', rotation=18, labelsize=8)
    ax6.tick_params(axis='y', colors='#94A3B8')
    ax6.legend(loc='upper right', framealpha=0.4, labelcolor='white',
               facecolor='#1E293B', edgecolor='#334155', fontsize=8)

    plt.tight_layout(rect=[0, 0, 1, 0.96])
    plt.savefig('security_dashboard.png', dpi=150, bbox_inches='tight',
                facecolor='#0F172A')
    print('📊 Dashboard saved → security_dashboard.png')


# Copy build_excel_report from scanner
def build_excel_report(df: pd.DataFrame, risk_report: dict, filepath: str):
    wb   = Workbook()
    meta = risk_report['meta']
    sc   = risk_report['sev_counts']
    thin = Side(style='thin', color='D1D5DB')
    bdr  = Border(left=thin, right=thin, top=thin, bottom=thin)

    def hdr_fill(hex_col):
        return PatternFill('solid', fgColor=hex_col)

    def cell_font(bold=False, size=10, color='000000', name='Arial'):
        return Font(bold=bold, size=size, color=color, name=name)

    def write_kv(ws, row, label, value, label_bg='F1F5F9',
                 val_bg='FFFFFF', bold_val=False, val_color='000000'):
        lc = ws.cell(row=row, column=1, value=label)
        lc.font   = cell_font(bold=True, size=10)
        lc.fill   = hdr_fill(label_bg)
        lc.border = bdr
        lc.alignment = Alignment(vertical='center', indent=1)
        ws.merge_cells(start_row=row, start_column=2,
                       end_row=row, end_column=8)
        vc = ws.cell(row=row, column=2, value=value)
        vc.font   = cell_font(bold=bold_val, size=10, color=val_color)
        vc.fill   = hdr_fill(val_bg)
        vc.border = bdr
        vc.alignment = Alignment(vertical='center', wrap_text=False)

    # SHEET 1 — EXECUTIVE SUMMARY
    ws1 = wb.active
    ws1.title = '📊 Executive Summary'
    ws1.sheet_view.showGridLines = False

    # Banner
    ws1.merge_cells('A1:H1')
    c = ws1['A1']
    c.value     = '🔐  AI-POWERED GITHUB SECURITY VULNERABILITY REPORT'
    c.font      = cell_font(bold=True, size=16, color='FFFFFF')
    c.fill      = hdr_fill('0F172A')
    c.alignment = Alignment(horizontal='center', vertical='center')
    ws1.row_dimensions[1].height = 42

    ws1.merge_cells('A2:H2')
    c = ws1['A2']
    c.value     = (f'Generated: {meta["scanned_at"]}  |  '
                   f'AI Model: {HF_MODEL}  |  OSV Dependency Scanning')
    c.font      = cell_font(size=9, color='94A3B8')
    c.fill      = hdr_fill('1E293B')
    c.alignment = Alignment(horizontal='center')
    ws1.row_dimensions[2].height = 20

    # Section: Repo Info
    ws1.merge_cells('A4:H4')
    c = ws1['A4']
    c.value     = '📌  REPOSITORY INFORMATION'
    c.font      = cell_font(bold=True, size=11, color='FFFFFF')
    c.fill      = hdr_fill('1E3A5F')
    c.alignment = Alignment(indent=1, vertical='center')
    ws1.row_dimensions[4].height = 24

    repo_rows = [
        ('Repository',  meta['full_name']),
        ('URL',         meta['url']),
        ('Language',    meta['language']),
        ('Description', meta['description']),
        ('Stars',       str(meta['stars'])),
        ('Forks',       str(meta['forks'])),
        ('Repo Size',   f"{meta['size_kb']:,} KB"),
    ]
    for i, (lbl, val) in enumerate(repo_rows, start=5):
        write_kv(ws1, i, lbl, val)
        ws1.row_dimensions[i].height = 18

    # Section: Risk Assessment
    r = 13
    ws1.merge_cells(f'A{r}:H{r}')
    c = ws1[f'A{r}']
    c.value     = '⚠️  RISK ASSESSMENT'
    c.font      = cell_font(bold=True, size=11, color='FFFFFF')
    c.fill      = hdr_fill('3B1F4E')
    c.alignment = Alignment(indent=1, vertical='center')
    ws1.row_dimensions[r].height = 24

    write_kv(ws1, r+1, 'Total Risk Score', str(risk_report['total_score']), bold_val=True)
    cls_hex = risk_report['cls_color'].replace('#','')
    write_kv(ws1, r+2, 'Risk Classification', risk_report['classification'],
             val_bg=cls_hex, val_color='FFFFFF', bold_val=True)
    write_kv(ws1, r+3, 'Total Vulnerabilities', str(len(df)), bold_val=True)

    for idx, sev in enumerate(['Critical', 'High', 'Medium', 'Low'], start=r+4):
        cnt = sc.get(sev, 0)
        write_kv(ws1, idx, f'  {sev}', str(cnt),
                 val_bg=SEVERITY_BG_HEX[sev],
                 val_color=SEVERITY_FG_HEX[sev],
                 bold_val=cnt > 0)
        ws1.row_dimensions[idx].height = 18

    # Section: Finding Breakdown by Type
    r2 = r + 9
    ws1.merge_cells(f'A{r2}:H{r2}')
    c = ws1[f'A{r2}']
    c.value     = '📁  BREAKDOWN BY VULNERABILITY CATEGORY'
    c.font      = cell_font(bold=True, size=11, color='FFFFFF')
    c.fill      = hdr_fill('1A3A2A')
    c.alignment = Alignment(indent=1, vertical='center')
    ws1.row_dimensions[r2].height = 24

    for idx, (vtype, cnt) in enumerate(risk_report['type_counts'].items(), start=r2+1):
        write_kv(ws1, idx, vtype, str(cnt))
        ws1.row_dimensions[idx].height = 18

    ws1.column_dimensions['A'].width = 32
    for col in ['B','C','D','E','F','G','H']:
        ws1.column_dimensions[col].width = 16

    # SHEET 2 — DETAILED FINDINGS
    ws2 = wb.create_sheet('🔍 Detailed Findings')
    ws2.sheet_view.showGridLines = False
    ws2.freeze_panes = 'A3'

    DETAIL_COLS = [
        ('Repository Name',    18),
        ('File Name',          38),
        ('Line #',             8),
        ('Type',               26),
        ('Vulnerability',      38),
        ('Severity',           12),
        ('Score',              8),
        ('Code Snippet',       42),
        ('AI Explanation',     52),
        ('Risk Impact',        46),
        ('Recommended Fix',    52),
        ('Secure Code',        55),
        ('Reference',          38),
    ]
    DF_COLS = [
        'Repository Name', 'File Name', 'Line Number',
        'Vulnerability Type', 'Vulnerability Name', 'Severity', 'Risk Score',
        'Code Snippet', 'AI Explanation', 'Risk Impact',
        'Recommended Fix', 'Secure Code Example', 'Reference Link'
    ]

    ws2.merge_cells(start_row=1, start_column=1, end_row=1, end_column=len(DETAIL_COLS))
    c = ws2.cell(row=1, column=1, value='🔍  DETAILED VULNERABILITY FINDINGS WITH AI REMEDIATION')
    c.font      = cell_font(bold=True, size=13, color='FFFFFF')
    c.fill      = hdr_fill('0F172A')
    c.alignment = Alignment(horizontal='center', vertical='center')
    ws2.row_dimensions[1].height = 30

    for ci, (hdr, w) in enumerate(DETAIL_COLS, start=1):
        c = ws2.cell(row=2, column=ci, value=hdr)
        c.font      = cell_font(bold=True, size=10, color='FFFFFF')
        c.fill      = hdr_fill('1E3A5F')
        c.border    = bdr
        c.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
        ws2.column_dimensions[get_column_letter(ci)].width = w
    ws2.row_dimensions[2].height = 26

    for ri, row in enumerate(df[DF_COLS].itertuples(index=False), start=3):
        sev    = row[5]
        alt_bg = 'F8FAFC' if ri % 2 == 0 else 'FFFFFF'

        for ci, val in enumerate(row, start=1):
            c = ws2.cell(row=ri, column=ci, value=(str(val) if val is not None else ''))
            c.border    = bdr
            c.alignment = Alignment(vertical='top', wrap_text=True)
            c.font      = Font(size=9, name='Arial')

            if ci == 6 or ci == 7:
                c.fill      = hdr_fill(SEVERITY_BG_HEX.get(sev, 'FFFFFF'))
                c.font      = cell_font(bold=True, size=9, color=SEVERITY_FG_HEX.get(sev, '000000'))
                c.alignment = Alignment(horizontal='center', vertical='top')
            elif ci == 12:
                c.fill = hdr_fill('F0FDF4')
                c.font = Font(size=8, name='Courier New', color='15803D')
            else:
                c.fill = hdr_fill(alt_bg)

        ws2.row_dimensions[ri].height = 72

    wb.save(filepath)
    print(f'✅ Excel report saved → {filepath}')


# Generate Mock Findings
mock_vulns = [
    {
        'Repository Name': TARGET_REPO,
        'File Name': 'src/main/resources/application.properties',
        'Line Number': 12,
        'Vulnerability Type': 'Hardcoded Secret',
        'Vulnerability Name': 'Hardcoded Password',
        'Severity': 'Critical',
        'Risk Score': 4,
        'Code Snippet': 'spring.datasource.password=[REDACTED]',
        'Reference Link': 'https://cwe.mitre.org/data/definitions/259.html',
        'AI Explanation': 'A plaintext password is hardcoded directly in the application configuration file, exposing sensitive credentials to anyone with read access to the code repository.',
        'Risk Impact': 'An attacker accessing the code repository can compromise the database server, leading to data exfiltration, service disruption, or unauthorized modifications.',
        'Recommended Fix': '1. Move credentials to environment variables.\n2. Reference the environment variable in application.properties using ${DB_PASSWORD}.\n3. Restrict database access to authorized IP ranges.',
        'Secure Code Example': 'spring.datasource.password=${DB_PASSWORD}'
    },
    {
        'Repository Name': TARGET_REPO,
        'File Name': 'src/main/java/com/example/demo/UserController.java',
        'Line Number': 45,
        'Vulnerability Type': 'SQL Injection',
        'Vulnerability Name': 'SQL Injection Risk (String concat)',
        'Severity': 'Critical',
        'Risk Score': 4,
        'Code Snippet': 'String query = "SELECT * FROM users WHERE username = \'" + input + "\'";',
        'Reference Link': 'https://owasp.org/www-community/attacks/SQL_Injection',
        'AI Explanation': 'The application constructs an SQL query by dynamically concatenating user-supplied input strings, allowing malicious users to manipulate the query structure.',
        'Risk Impact': 'Attackers can execute arbitrary SQL statements, bypass authentication, retrieve all database tables, modify data, or execute OS commands on the database server.',
        'Recommended Fix': '1. Use parameterized queries or PreparedStatement exclusively.\n2. Utilize Spring Data JPA or Hibernate repository interfaces.\n3. Validate and sanitize user inputs.',
        'Secure Code Example': 'String query = "SELECT * FROM users WHERE username = ?";\nPreparedStatement ps = conn.prepareStatement(query);\nps.setString(1, input);'
    },
    {
        'Repository Name': TARGET_REPO,
        'File Name': 'src/main/java/com/example/demo/SecurityConfig.java',
        'Line Number': 22,
        'Vulnerability Type': 'Broken Access Control',
        'Vulnerability Name': 'Spring Security Disabled (permitAll)',
        'Severity': 'High',
        'Risk Score': 3,
        'Code Snippet': '.requestMatchers("/admin/**").permitAll()',
        'Reference Link': 'https://owasp.org/www-project-top-ten/2017/A5_2017-Broken_Access_Control',
        'AI Explanation': 'The URL pattern matching administrative endpoints is configured with permitAll(), which bypasses all security checks and roles requirements.',
        'Risk Impact': 'Unauthenticated external users can access administrative actions, view internal logs, alter user permissions, or compromise the system administration console.',
        'Recommended Fix': '1. Require admin role for matching patterns.\n2. Implement robust method security using @PreAuthorize.\n3. Keep default rule as authenticated().',
        'Secure Code Example': '.requestMatchers("/admin/**").hasRole("ADMIN")'
    },
    {
        'Repository Name': TARGET_REPO,
        'File Name': 'src/main/java/com/example/demo/CryptoUtils.java',
        'Line Number': 50,
        'Vulnerability Type': 'Weak Cryptography',
        'Vulnerability Name': 'Weak Hash — MD5',
        'Severity': 'High',
        'Risk Score': 3,
        'Code Snippet': 'MessageDigest.getInstance("MD5")',
        'Reference Link': 'https://cwe.mitre.org/data/definitions/327.html',
        'AI Explanation': 'The MD5 hash function is cryptographically broken and prone to collision attacks, meaning different inputs can produce identical hash outputs.',
        'Risk Impact': 'Attacker can forge messages, bypass integrity checks, or easily reverse hashed passwords using lookup tables (rainbow tables).',
        'Recommended Fix': '1. Upgrade hashes to SHA-256 or SHA-3.\n2. For passwords, use BCrypt or PBKDF2.\n3. Introduce secure salts.',
        'Secure Code Example': 'MessageDigest.getInstance("SHA-256")'
    },
    {
        'Repository Name': TARGET_REPO,
        'File Name': 'src/main/java/com/example/demo/LoggingFilter.java',
        'Line Number': 89,
        'Vulnerability Type': 'Information Disclosure',
        'Vulnerability Name': 'Stack Trace Exposure (printStackTrace)',
        'Severity': 'Medium',
        'Risk Score': 2,
        'Code Snippet': 'e.printStackTrace();',
        'Reference Link': 'https://cwe.mitre.org/data/definitions/209.html',
        'AI Explanation': 'Printing exception stack traces to standard output streams writes sensitive execution details directly to application server logs or client responses.',
        'Risk Impact': 'Attackers obtain detailed reconnaissance on internal class layouts, libraries, versions, database schema names, or filesystem directories to craft custom exploits.',
        'Recommended Fix': '1. Replace e.printStackTrace() with structured log.error() calls.\n2. Use a centralized logging server.\n3. Return client-friendly error descriptions.',
        'Secure Code Example': 'log.error("Operation failed: {}", e.getMessage(), e);'
    },
    {
        'Repository Name': TARGET_REPO,
        'File Name': 'src/main/resources/application-dev.yml',
        'Line Number': 4,
        'Vulnerability Type': 'Misconfiguration',
        'Vulnerability Name': 'Debug Mode Enabled',
        'Severity': 'Medium',
        'Risk Score': 2,
        'Code Snippet': 'logging.level.root: DEBUG',
        'Reference Link': 'https://cwe.mitre.org/data/definitions/489.html',
        'AI Explanation': 'Root logging level is set to DEBUG which outputs highly verbose debug trace statements during runtime executions.',
        'Risk Impact': 'Verbose logs might contain session tokens, SQL query inputs, personal details, or credentials printed in clear text, which are stored in the server log files.',
        'Recommended Fix': '1. Set logging root level to INFO or WARN for production profiles.\n2. Separate dev and prod environments with spring profiles.\n3. Set show-sql configuration to false.',
        'Secure Code Example': 'logging.level.root: WARN'
    }
]

df = pd.DataFrame(mock_vulns)
total_score = int(df['Risk Score'].sum())
sev_counts  = df['Severity'].value_counts().to_dict()
type_counts = df['Vulnerability Type'].value_counts().to_dict()

# Calculate classification based on RISK_BANDS
classification, cls_color = 'Safe', '#2ECC71'
for threshold, label, color in RISK_BANDS:
    if total_score <= threshold:
        classification, cls_color = label, color
        break

meta = {
    'name': 'spring-ai-ollama',
    'full_name': 'mayureshnadkar-beep/spring-ai-ollama',
    'url': 'https://github.com/mayureshnadkar-beep/spring-ai-ollama',
    'language': 'Java',
    'description': 'Spring AI integrations using Ollama local models.',
    'stars': 15,
    'forks': 5,
    'size_kb': 2048,
    'scanned_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
}

risk_report = {
    'total_score': total_score,
    'classification': classification,
    'cls_color': cls_color,
    'sev_counts': sev_counts,
    'type_counts': type_counts,
    'top_files': df['File Name'].value_counts().head(5).to_dict(),
    'meta': meta
}

# Run generation
draw_visualizations(df, risk_report)
build_excel_report(df, risk_report, OUTPUT_XLSX)
print('✅ Test execution complete! security_dashboard.png and github_security_vulnerability_report.xlsx generated successfully!')
