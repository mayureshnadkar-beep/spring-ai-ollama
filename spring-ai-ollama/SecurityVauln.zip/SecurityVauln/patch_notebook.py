import json

# Load notebook
with open('hf_github_security_scanner.ipynb', 'r', encoding='utf-8') as f:
    nb = json.load(f)

# Update cell 1 (install dependencies)
cell_1_code = """import subprocess, sys

# Ensure UTF-8 printing on Windows console
if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8')

PACKAGES = [
    'requests', 'pandas', 'openpyxl', 'PyGithub',
    'matplotlib', 'seaborn', 'tqdm',
    'huggingface_hub', 'lxml'
]

print('Installing packages...\\n')
for pkg in PACKAGES:
    result = subprocess.run(
        [sys.executable, '-m', 'pip', 'install', pkg, '-q', '--upgrade'],
        capture_output=True, text=True
    )
    status = '✅' if result.returncode == 0 else '❌'
    print(f'  {status}  {pkg}')

print('\\n🎉 All dependencies ready!')"""

# Update cell 1
for cell in nb['cells']:
    if cell['cell_type'] == 'code' and 'PACKAGES = [' in ''.join(cell['source']):
        cell['source'] = [line + '\n' for line in cell_1_code.splitlines()]
        if cell['source']:
            cell['source'][-1] = cell['source'][-1].rstrip('\n')
        break

# Update cell 3 (Imports and config) to make tqdm robust
for cell in nb['cells']:
    if cell['cell_type'] == 'code' and 'from tqdm.notebook import tqdm' in ''.join(cell['source']):
        source_str = ''.join(cell['source'])
        source_str = source_str.replace('from tqdm.notebook import tqdm', 'from tqdm import tqdm')
        cell['source'] = [line + '\n' for line in source_str.splitlines()]
        if cell['source']:
            cell['source'][-1] = cell['source'][-1].rstrip('\n')
        break

# Update all cells to replace g.get_rate_limit().core with g.get_rate_limit().rate
for cell in nb['cells']:
    if cell['cell_type'] == 'code':
        source_str = ''.join(cell['source'])
        if 'get_rate_limit().core' in source_str:
            source_str = source_str.replace('get_rate_limit().core', 'get_rate_limit().rate')
            cell['source'] = [line + '\n' for line in source_str.splitlines()]
            if cell['source']:
                cell['source'][-1] = cell['source'][-1].rstrip('\n')

# Update cell 5 (walk function depth limit and directory exclusions)
for cell in nb['cells']:
    if cell['cell_type'] == 'code' and 'def fetch_repo_files(' in ''.join(cell['source']):
        source_str = ''.join(cell['source'])
        source_str = source_str.replace(
            "if item.type == 'dir' and depth < 6:",
            "if item.type == 'dir' and depth < 15:\n                if item.name.lower() in ('target', 'build', 'bin', 'out', '.git', '.gradle', 'node_modules'):\n                    continue"
        )
        cell['source'] = [line + '\n' for line in source_str.splitlines()]
        if cell['source']:
            cell['source'][-1] = cell['source'][-1].rstrip('\n')
        break

# Update cell 4 (write GITHUB_TOKEN and HF_TOKEN)
for cell in nb['cells']:
    if cell['cell_type'] == 'code' and 'GITHUB_TOKEN =' in ''.join(cell['source']):
        source_str = ''.join(cell['source'])
        source_str = source_str.replace("GITHUB_TOKEN = ''", "GITHUB_TOKEN = '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'")
        source_str = source_str.replace("HF_TOKEN     = ''", "HF_TOKEN     = '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'")
        cell['source'] = [line + '\n' for line in source_str.splitlines()]
        if cell['source']:
            cell['source'][-1] = cell['source'][-1].rstrip('\n')
        break

# Save patched notebook
with open('hf_github_security_scanner.ipynb', 'w', encoding='utf-8') as f:
    json.dump(nb, f, indent=1)

# Extract code cells to scanner.py
code_lines = []
for cell in nb['cells']:
    if cell['cell_type'] == 'code':
        source = ''.join(cell['source'])
        code_lines.append(source)
        code_lines.append('\n\n# ' + '='*60 + '\n\n')

with open('scanner.py', 'w', encoding='utf-8') as f:
    f.write('\n'.join(code_lines))

print('Notebook and scanner.py patched successfully!')
